
OPTCG Discord Bot - ready for GitHub and Render/Replit

Files:
- bot.py
- requirements.txt
- .gitignore
- data/ (initial json files)

DO NOT COMMIT your token. Use environment variables on the host.
